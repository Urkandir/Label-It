package com.example.aluno.projetotech;

public class Rotulo {
    private String id;
    private String name;
    private String xmax;
    private String xmin;
    private String ymax;
    private String ymin;

    public Rotulo() {}

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getXmax() {
        return xmax;
    }

    public String getXmin() {
        return xmin;
    }

    public String getYmax() {
        return ymax;
    }

    public String getYmin() {
        return ymin;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setXmax(String xmax) {
        this.xmax = xmax;
    }

    public void setXmin(String xmin) {
        this.xmin = xmin;
    }

    public void setYmax(String ymax) {
        this.ymax = ymax;
    }

    public void setYmin(String ymin) {
        this.ymin = ymin;
    }
}


/*public class Rotulo {
    private String id;
    private String name;
    private String xmax;
    private String xmin;
    private String ymax;
    private String ymin;

    public Rotulo() {}

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getXmax() {
        return xmax;
    }

    public String getXmin() {
        return xmin;
    }

    public String getYmax() {
        return ymax;
    }

    public String getYmin() {
        return ymin;
    }
}*/
